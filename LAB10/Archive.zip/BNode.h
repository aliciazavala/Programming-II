/*
* @author Alicia Zavala
* @date
* @file BNode.h
* @brief
*/
#ifndef BNODE_H
#define BNODE_H

#include <iostream>

template <typename itemType>
class BNode
{
  private:
    itemType item;
    BNode<itemType>* leftC;
    BNode<itemType>* rightC;

  public:
   BNode();
   BNode(const itemType& entry);
   BNode(const BNode<itemType>& other);

   itemType& getItem();
   BNode<itemType>* getLeft() const;
   BNode<itemType>* getRight() const;

   void setItem(itemType& entry);
   void setLeft(BNode<itemType>* left);
   void setRight(BNode<itemType>* right);

   ~BNode();
};
#include "BNode.cpp"
#endif


