
#include <iostream>
#include <stdexcept>

using namespace std;

template <typename itemType,typename keyType>
BST<itemType,keyType>::BST()
{
    m_root = nullptr;
}

template <typename itemType,typename keyType>
BST<itemType,keyType>::~BST()
{
    deleteTree(m_root);
}
template <typename itemType,typename keyType>
void BST<itemType,keyType>::deleteTree()
{
    deleteTree(m_root);
}
template <typename itemType,typename keyType>
void BST<itemType,keyType>::deleteTree(BNode<itemType>* tree)
{
	if(tree != nullptr)
	{
		BNode<itemType>* temp = tree;
		deleteTree(tree->getLeft());
		deleteTree(tree->getRight());
		delete (temp);
	}
		
}
template <typename itemType,typename keyType>
void BST<itemType,keyType>::remove(BNode<itemType>* tree)
{
    /*//No children
    if(tree->getLeft()==nullptr && tree->getRight()==nullptr) {
        delete tree;
        //tree = nullptr;
    }
    //Node has only one child 
    else if((tree->getLeft() == nullptr && tree->getRight() != nullptr)
    {
        remove(tree-> getRight();
    }
    else if(tree-> getRight()) == nullptr && tree->getLeftChild() != nullptr)) {
        remove(tree->getLeftChild())
    }
    //Node has two children
    else {
        ItemType inorderSuccessor;
        //Find Inorder Successor node, return its entry to temporary pointer, delete original Inorder Successor node
        BinaryNode<ItemType>* tempPtr = removeLeftmostNode(tree -> getRightChildPtr(), inorderSuccessor);
        tree -> setRightChildPtr(tempPtr);
        //Change node's Item to Inorder Successor's Item
        tree -> setItem(inorderSuccessor);
    }*/
}
template <typename itemType,typename keyType>
BST<itemType,keyType>::BST(BST<itemType,keyType>& original)
{
    m_root = copy(original.m_root);

}
template <typename itemType,typename keyType>
BNode<itemType>* BST<itemType,keyType>::copy(BNode<itemType>* originalTree)
{
    BNode<itemType>* temp = nullptr;
    if(originalTree != nullptr)
    {
        temp = new BNode<itemType>(originalTree->getItem());
        temp->setLeft(copy(originalTree -> getLeft()));
        temp->setRight(copy(originalTree -> getRight()));
    }
    return temp;
}

template <typename itemType, typename keyType>
void BST<itemType, keyType>::print(int option)
{
    print(option, m_root);
}
template <typename itemType, typename keyType>
void BST<itemType, keyType>::print(int option,BNode<itemType>* tree)
{
    if(tree == nullptr)
    {
        return;
    }
    if (option == 1)
    {
    //Pre order
        cout<<(tree->getItem());
        print(option,tree->getLeft());
        print(option,tree->getRight());
    } 
    // in order  
    if(option == 2)
    {
        print(option,tree->getLeft());
        cout<<(tree->getItem());
        print(option,tree->getRight());
    }
    // post order
    if(option == 3)
    {
        print(option,tree->getLeft());
        print(option,tree->getRight());
        cout<<(tree->getItem());
    }
}     

template <typename itemType, typename keyType>
void BST<itemType, keyType>::add(itemType entry, keyType id)
{

    find(id,m_root);
    if(found == true)
    {
        throw runtime_error("Item already with that ID added.");
    }
    if(m_root==nullptr)
    { 
       m_root = new BNode<itemType>(entry);
    }
    else
    {
        add(entry,m_root,id);
    }
    
}

template <typename itemType, typename keyType>
void BST<itemType, keyType>::add(itemType entry,BNode<itemType>* tree,keyType id)
{
	if(tree->getItem() > id)
    {
        if(tree->getLeft() == nullptr)
        {
            BNode<itemType>* temp = new BNode<itemType>(entry);
            tree->setLeft(temp);
            return;
        }
		add(entry,tree->getLeft(),id);
	}
	else if(tree->getItem() < id){
        if(tree->getRight() == nullptr)
        {
            BNode<itemType>* temp = new BNode<itemType>(entry);
            tree->setRight(temp);
            return;
        }
		add(entry,tree->getRight(),id);
	}

}

template <typename itemType,typename keyType>
void BST<itemType, keyType>::search(keyType key, BNode<itemType>* tree)
{
    if (tree!= nullptr)
    {
        if (tree->getItem() == key)
        {
            found = true;
            cout<<tree->getItem();
        }
        else if (tree->getItem() > key)
        {
            search(key, tree->getLeft());
        }
        else
        {
            search(key, tree->getRight());
        }
    }
    if(found == false)
    {
        throw runtime_error("Item not found\n");
    }
}
template <typename itemType,typename keyType>
void BST<itemType, keyType>::search(keyType key)
{
    found = false;
    search(key,m_root);
}

template <typename itemType,typename keyType>
bool BST<itemType, keyType>::find(keyType id,BNode<itemType>* tree)
{
    if (tree!= nullptr)
    {
        if (tree->getItem() == id)
        {
            found = true;
            return true;
        }
            find(id, tree->getLeft());
            find(id, tree->getRight());
    }
    return false;
}

