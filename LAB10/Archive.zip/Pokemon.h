/*
* @author Alicia Zavala
* @date
* @file Pokemon.h
* @brief
*/
#ifndef POKEMON_H
#define POKEMON_H

#include <iostream>
#include <string>

using namespace std;

class Pokemon
{
    private:
        string US_name;
        string JP_name;
        int pID;

    public:
        Pokemon();
        Pokemon(string US,string JP, int ID);
        ~Pokemon();
        string getUSname()const;
        string getJPname()const;
        int getID()const;
        bool operator <(int key) const;
        bool operator >(int key) const;
        bool operator ==(int key) const;
        friend ostream& operator<<(ostream &out, const Pokemon& pk)
        {
            out<< pk.US_name <<"      \t\t"<<pk.pID<<"      \t\t"<<pk.JP_name<<'\n';
            return out; 
        }
};
#endif