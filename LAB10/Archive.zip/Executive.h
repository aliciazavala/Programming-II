#include "Pokemon.h"
#include "BinarySearchTree.h"

#ifndef EXECUTIVE_H
#define EXECUTIVE_H

#include <iostream>
#include <fstream>

using namespace std;

class Executive
{
    private:
    ifstream inFile;
    int option;
    int order;
    int treeOption;
    bool quit = false;
    int key;
    
    public:
    Executive(string filename);
    ~Executive();
    void run(BST<Pokemon, int>& Pokedex);
    void read(ifstream& file,BST<Pokemon, int>& Pokedex);
    void menu(BST<Pokemon, int>& Pokedex,BST<Pokemon, int>& copyP);
    void Add(BST<Pokemon, int>& Pokedex);
    void Search(BST<Pokemon, int>& Pokedex);
    void Print(BST<Pokemon, int>& Pokedex);
    void Remove(BST<Pokemon, int>& Pokedex);
};

#endif