/*
* @author Alicia Zavala
* @date
* @file BinarySearchTree.h
* @brief
*/
#include "BNode.h"
#ifndef BST_H
#define BST_H

#include <iostream>
#include <stdexcept>

using namespace std;
template <typename itemType,typename keyType>
class BST
{
  private:
  BNode<itemType>* m_root;
  void search(keyType key, BNode<itemType>* tree);
  void add(itemType entry,BNode<itemType>* tree,keyType id);
  void print(int option,BNode<itemType>* tree);
  bool found;

  public:
  BST();
  BST(BST<itemType,keyType>& original);
  ~BST();
  BNode<itemType>* copy(BNode<itemType>* original);
  void add(itemType entry, keyType id);
  void remove();
  void remove(BNode<itemType>* tree);
  void deleteTree();
  void deleteTree(BNode<itemType>* tree);
  void print(int option);
  void search(keyType key);
  bool find(keyType entry,BNode<itemType>* tree);
  
};
#include "BinarySearchTree.cpp"
#endif


